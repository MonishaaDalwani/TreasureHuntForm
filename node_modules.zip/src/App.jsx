import { useState } from "react";
import "./App.css";

function App() {
  const years = ["FE", "SE", "TE", "BE"];
  const branches = ["COMPUTER ENGINEERING(COMPS)", "INFORMATION TECHNOLOGY(IT)", "ARTIFICIAL INTELLIGENCE AND DATA SCIENCE(AI & DS)", "CHEMICAL(CHEM)","ELECTRONICS AND TELECOMMUNICATION(EXTC)"];

  const [formData, setFormData] = useState({
    teamName: "",
    leader: { name: "", email: "", phone: "", year: "", branch: "" },
    players: [
      { name: "", year: "", branch: "" },
      { name: "", year: "", branch: "" },
      { name: "", year: "", branch: "" },
    ],
  });

  const [errors, setErrors] = useState({});

  const handleTeamChange = (e) => setFormData({ ...formData, teamName: e.target.value });
  const handleLeaderChange = (field, value) =>
    setFormData({ ...formData, leader: { ...formData.leader, [field]: value } });
  const handlePlayerChange = (index, field, value) => {
    const updatedPlayers = [...formData.players];
    updatedPlayers[index][field] = value;
    setFormData({ ...formData, players: updatedPlayers });
  };

  const validate = () => {
    let newErrors = {};
    if (!formData.teamName.trim()) newErrors.teamName = "Team name is required";

    if (!formData.leader.name.trim()) newErrors.leaderName = "Leader name is required";
    if (!formData.leader.email.trim()) newErrors.leaderEmail = "Leader email is required";
    if (!formData.leader.phone.trim()) newErrors.leaderPhone = "Leader phone is required";
    if (!formData.leader.year) newErrors.leaderYear = "Leader year is required";
    if (!formData.leader.branch) newErrors.leaderBranch = "Leader branch is required";

    formData.players.forEach((p, i) => {
      if (!p.name.trim()) newErrors[`playerName${i}`] = `Player ${i + 2} name is required`;
      if (!p.year) newErrors[`playerYear${i}`] = `Player ${i + 2} year is required`;
      if (!p.branch) newErrors[`playerBranch${i}`] = `Player ${i + 2} branch is required`;
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      let playersInfo = formData.players
        .map((p, i) => `Player ${i + 2}: ${p.name}, ${p.year}, ${p.branch}`)
        .join("\n");
      alert(`✅ Treasure Hunt Registration Successful!\nTeam: ${formData.teamName}\nLeader: ${formData.leader.name}, ${formData.leader.email}, ${formData.leader.phone}, ${formData.leader.year}, ${formData.leader.branch}\n${playersInfo}`);
      
      setFormData({
        teamName: "",
        leader: { name: "", email: "", phone: "", year: "", branch: "" },
        players: [
          { name: "", year: "", branch: "" },
          { name: "", year: "", branch: "" },
          { name: "", year: "", branch: "" },
        ],
      });
      setErrors({});
    }
  };

  return (
    <div className="container">
      <div className="event-info">
        <h1>Treasure Hunt 2025</h1>
        <p>
          Join the annual Treasure Hunt event! Form a team and complete exciting challenges.
        </p>
        <h3>How to Register:</h3>
        <ol>
          <li>Enter your team name.</li>
          <li>Fill in the Team Leader's details (Name, Email, Phone, Year, Branch).</li>
          <li>Enter details for 3 additional team members (Name, Year, Branch).</li>
          <li>Click "Register Team".</li>
        </ol>
      </div>

      <form className="form" onSubmit={handleSubmit}>
        <div className="form-columns">
          <div className="column">
            <div className="player-box">
              <h3>Team Info</h3>
              <input type="text" placeholder="Team Name" value={formData.teamName} onChange={handleTeamChange}/>
              {errors.teamName && <p className="error">{errors.teamName}</p>}
            </div>

            <div className="player-box">
              <h3>Team Leader</h3>
              <div className="input-row">
                <input type="text" placeholder="Leader Name" value={formData.leader.name} onChange={(e)=>handleLeaderChange("name", e.target.value)}/>
                <input type="email" placeholder="Leader Email" value={formData.leader.email} onChange={(e)=>handleLeaderChange("email", e.target.value)}/>
              </div>
              <div className="input-row">
                <input type="tel" placeholder="Leader Phone" value={formData.leader.phone} onChange={(e)=>handleLeaderChange("phone", e.target.value)}/>
                <select value={formData.leader.year} onChange={(e)=>handleLeaderChange("year", e.target.value)}>
                  <option value="">Year</option>
                  {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
                <select value={formData.leader.branch} onChange={(e)=>handleLeaderChange("branch", e.target.value)}>
                  <option value="">Branch</option>
                  {branches.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <div className="error-row">
                {errors.leaderName && <p className="error">{errors.leaderName}</p>}
                {errors.leaderEmail && <p className="error">{errors.leaderEmail}</p>}
                {errors.leaderPhone && <p className="error">{errors.leaderPhone}</p>}
                {errors.leaderYear && <p className="error">{errors.leaderYear}</p>}
                {errors.leaderBranch && <p className="error">{errors.leaderBranch}</p>}
              </div>
            </div>
          </div>

          <div className="column">
            {formData.players.map((player, i) => (
              <div key={i} className="player-box">
                <h3>Player {i + 2}</h3>
                <div className="input-row">
                  <input type="text" placeholder="Full Name" value={player.name} onChange={(e)=>handlePlayerChange(i,"name", e.target.value)}/>
                  <select value={player.year} onChange={(e)=>handlePlayerChange(i,"year", e.target.value)}>
                    <option value="">Year</option>
                    {years.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                  <select value={player.branch} onChange={(e)=>handlePlayerChange(i,"branch", e.target.value)}>
                    <option value="">Branch</option>
                    {branches.map(b => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
                <div className="error-row">
                  {errors[`playerName${i}`] && <p className="error">{errors[`playerName${i}`]}</p>}
                  {errors[`playerYear${i}`] && <p className="error">{errors[`playerYear${i}`]}</p>}
                  {errors[`playerBranch${i}`] && <p className="error">{errors[`playerBranch${i}`]}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
        <button type="submit">Register Team</button>
      </form>
    </div>
  );
}

export default App;
